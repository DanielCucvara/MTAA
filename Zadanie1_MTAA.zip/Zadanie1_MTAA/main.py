# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.
import sipfullproxy
import socketserver
HOST, PORT = '0.0.0.0', 5060
recordroute = None
topvia = None
ipaddress = ""
import re
import string
import socket
#import threading
import sys
import time
import logging


def init_global():
    global recordroute
    global topvia
    global ipaddress
    global HOST
    global PORT
    HOST, PORT = '0.0.0.0', 5060
    ipaddress = "172.20.10.11"
    recordroute = "Record-Route: <sip:%s:%d;lr>" % (ipaddress, PORT)
    topvia = "Via: SIP/2.0/UDP %s:%d" % (ipaddress, PORT)


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    init_global()
    sipfullproxy.registrar = {}
    print()
    sipfullproxy.recordroute = recordroute
    sipfullproxy.topvia = topvia
    sipfullproxy.HOST = HOST
    sipfullproxy.PORT = PORT
    sipfullproxy.run_proxy()

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
